# This file was automatically created by FeynRules 2.3.41
# Mathematica version: 12.1.1 for Mac OS X x86 (64-bit) (June 19, 2020)
# Date: Thu 2 Jun 2022 19:29:03


from object_library import all_orders, CouplingOrder


QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 2)

Ol5 = CouplingOrder(name = 'Ol5',
                    expansion_order = 99,
                    hierarchy = 1)

Oyo = CouplingOrder(name = 'Oyo',
                    expansion_order = 99,
                    hierarchy = 1)

